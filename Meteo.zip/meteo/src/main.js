import './style.css'; // opzionale se hai CSS aggiuntivo
import PocketBase from "pocketbase";

// CONFIGURAZIONE - modifica qui se necessario
const POCKETBASE_URL = "http://127.0.0.1:8090";
const COLLECTION_NAME = "meteo"; // meteo o prova - usa il nome esatto della collection
const pb = new PocketBase(POCKETBASE_URL);

// Inizializza mappa Leaflet
const map = L.map('map').setView([41.9, 12.5], 6);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Variabili globali
const markers = new Map(); // recordId -> marker
const pointsListEl = document.getElementById('pointsList');
const statsEl = document.getElementById('stats');
const refreshTempsBtn = document.getElementById('refreshTempsBtn');
const reloadBtn = document.getElementById('reloadBtn');

// Imposta colori legenda (puoi cambiare)
const tempColor = (t) => {
  if (t === null || isNaN(t)) return '#777';
  if (t < 0) return '#2b83ba';
  if (t < 10) return '#66c2a5';
  if (t < 20) return '#fdae61';
  return '#d7191c';
};
// imposta swatch colori nella UI
document.getElementById('sw-cold').style.background = tempColor(-5);
document.getElementById('sw-cool').style.background = tempColor(5);
document.getElementById('sw-warm').style.background = tempColor(15);
document.getElementById('sw-hot').style.background = tempColor(25);

// --- API helpers ---
async function getPlaceName(lat, lon) {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&zoom=8`;
    const res = await fetch(url, { headers: { 'Accept': 'application/json', 'User-Agent': 'MappaMeteoDemo/1.0 (your-email@domain)' }});
    const data = await res.json();
    return data.display_name || "Località sconosciuta";
  } catch (e) {
    console.warn("Nominatim fallito:", e);
    return "Località sconosciuta";
  }
}

async function getTemperature(lat, lon) {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
    const res = await fetch(url);
    const data = await res.json();
    if (data && data.current_weather && typeof data.current_weather.temperature !== 'undefined') {
      return Number(data.current_weather.temperature);
    }
    return null;
  } catch (e) {
    console.warn("Open-Meteo fallito:", e);
    return null;
  }
}

// --- Marker creation & UI ---
function createMarkerFromRecord(rec) {
  // supporta diverse strutture: lat/lon numerici oppure geopoint string "lat,lon"
  let lat = Number(rec.lat);
  let lon = Number(rec.lon);
  if ((!lat || !lon) && rec.geopoint) {
    // geopoint potrebbe essere "lat,lon"
    const parts = String(rec.geopoint).split(',').map(p => p.trim());
    if (parts.length >= 2) {
      lat = Number(parts[0]);
      lon = Number(parts[1]);
    }
  }

  if (!isFinite(lat) || !isFinite(lon)) {
    console.warn("Record senza coordinate valide:", rec);
    return;
  }

  // colore basato sulla temperatura
  const temp = (typeof rec.temperatura !== 'undefined') ? Number(rec.temperatura) : null;
  const color = tempColor(temp);

  // crea marker con cerchio colorato
  const circle = L.circleMarker([lat, lon], {
    radius: 8,
    fillColor: color,
    color: '#333',
    weight: 1,
    opacity: 1,
    fillOpacity: 0.9
  }).addTo(map);

  const popupHtml = `
    <b>${rec.descrizione || '—'}</b><br>
    Temp: ${temp !== null && !isNaN(temp) ? temp + ' °C' : 'N/D'}<br>
    LAT: ${lat.toFixed(5)}<br>LON: ${lon.toFixed(5)}<br>
    <small>ID: ${rec.id}</small>
  `;
  circle.bindPopup(popupHtml);

  // conserva marker
  markers.set(rec.id, { marker: circle, record: rec });

  // aggiungi voce lista
  addPointListItem(rec, lat, lon, temp);
}

function clearMarkersAndList() {
  markers.forEach(({marker}) => map.removeLayer(marker));
  markers.clear();
  pointsListEl.innerHTML = '';
}

function addPointListItem(rec, lat, lon, temp) {
  const div = document.createElement('div');
  div.className = 'point-item';
  div.innerHTML = `
    <b>${rec.descrizione || '—'}</b><br>
    Temp: ${temp !== null && !isNaN(temp) ? temp + ' °C' : 'N/D'}<br>
    <small>${lat.toFixed(5)}, ${lon.toFixed(5)}</small>
    <div style="margin-top:6px">
      <button data-id="${rec.id}" class="zoomBtn">Zoom</button>
      <button data-id="${rec.id}" class="deleteBtn">Elimina</button>
    </div>
  `;
  pointsListEl.prepend(div);

  div.querySelector('.zoomBtn').onclick = () => {
    const recMarker = markers.get(rec.id);
    if (recMarker) {
      map.setView(recMarker.marker.getLatLng(), 12, { animate:true });
      recMarker.marker.openPopup();
    }
  };

  div.querySelector('.deleteBtn').onclick = async () => {
    if (!confirm("Eliminare questo punto?")) return;
    try {
      await pb.collection(COLLECTION_NAME).delete(rec.id);
      // rimuovi marker e voce lista
      const recMarker = markers.get(rec.id);
      if (recMarker) {
        map.removeLayer(recMarker.marker);
        markers.delete(rec.id);
      }
      div.remove();
      updateStatsFromCurrentMarkers();
    } catch (e) {
      console.error("Errore eliminazione:", e);
      alert("Impossibile eliminare il punto.");
    }
  };
}

// --- Statistiche ---
function updateStatsFromCurrentMarkers() {
  const temps = [];
  markers.forEach((v) => {
    const t = Number(v.record.temperatura);
    if (!isNaN(t)) temps.push(t);
  });

  const count = markers.size;
  const avg = temps.length ? (temps.reduce((a,b)=>a+b,0)/temps.length).toFixed(2) : '-';
  const min = temps.length ? Math.min(...temps) : '-';
  const max = temps.length ? Math.max(...temps) : '-';

  statsEl.innerHTML = `
    <b>Punti registrati:</b> ${count}<br>
    <b>Temperatura media:</b> ${avg === '-' ? '-' : avg + ' °C'}<br>
    <b>Minima:</b> ${min === '-' ? '-' : min + ' °C'}<br>
    <b>Massima:</b> ${max === '-' ? '-' : max + ' °C'}
  `;
}

// --- Interazione mappa: click per aggiungere punto ---
map.on('click', async (e) => {
  const lat = e.latlng.lat;
  const lon = e.latlng.lng;

  try {
    // ottieni descrizione e temperatura
    const [luogo, temperatura] = await Promise.all([
      getPlaceName(lat, lon),
      getTemperature(lat, lon)
    ]);

    // crea record su PocketBase
    // salviamo lat, lon, geopoint (string), descrizione, temperatura
    const payload = {
      lat,
      lon,
      geopoint: `${lat},${lon}`,
      descrizione: luogo,
      temperatura: temperatura
    };

    const created = await pb.collection(COLLECTION_NAME).create(payload);

    // mostra marker appena creato
    createMarkerFromRecord(created);

    // aggiorna statistiche
    updateStatsFromCurrentMarkers();

  } catch (err) {
    console.error("Errore durante la creazione del punto:", err);
    alert("Errore nel salvataggio del punto. Controlla console.");
  }
});

// --- Ricarica tutti i punti dalla collection (all'avvio e su richiesta) ---
async function loadAllPoints() {
  try {
    clearMarkersAndList();
    // getFullList() prende tutti i record (anche paginati w/ page size grande)
    const records = await pb.collection(COLLECTION_NAME).getFullList({ perPage: 200 });
    // records potrebbe venire con campi personalizzati; li gestiamo in createMarkerFromRecord
    records.forEach(rec => createMarkerFromRecord(rec));
    updateStatsFromCurrentMarkers();
  } catch (e) {
    console.error("Errore caricamento punti:", e);
    alert("Impossibile caricare i punti da PocketBase.");
  }
}

// --- Aggiorna temperature per tutti i punti salvati (chiamata a Open-Meteo per ogni punto, salva su PB) ---
async function refreshAllTemperatures() {
  if (!confirm("Aggiornare la temperatura per tutti i punti? Verranno fatte chiamate API per ogni punto.")) return;
  try {
    // leggi i record (id e lat/lon)
    const records = await pb.collection(COLLECTION_NAME).getFullList({ perPage: 200 });
    for (const rec of records) {
      let lat = Number(rec.lat), lon = Number(rec.lon);
      if ((!lat || !lon) && rec.geopoint) {
        const parts = String(rec.geopoint).split(',').map(p => p.trim());
        if (parts.length >= 2) {
          lat = Number(parts[0]); lon = Number(parts[1]);
        }
      }
      if (!isFinite(lat) || !isFinite(lon)) continue;
      const newTemp = await getTemperature(lat, lon);
      // aggiorna solo se ottenuto
      if (newTemp !== null) {
        await pb.collection(COLLECTION_NAME).update(rec.id, { temperatura: newTemp });
      }
    }
    // ricarica i punti dalla collection per aggiornare marker/popups/lista
    await loadAllPoints();
    alert("Aggiornamento temperature completato.");
  } catch (e) {
    console.error("Errore aggiornamento temperature:", e);
    alert("Errore durante l'aggiornamento delle temperature.");
  }
}

// bottone aggiorna temperature
refreshTempsBtn.onclick = refreshAllTemperatures;
reloadBtn.onclick = loadAllPoints;

// --- init ---
(async function init() {
  await loadAllPoints();
})();